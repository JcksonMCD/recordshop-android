package com.northcoders.recordshopapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.cache.annotation.EnableCaching;

@SpringBootTest
class RecordshopapiApplicationTests {

	@Test
	void contextLoads() {
	}


}
