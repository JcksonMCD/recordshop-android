package com.northcoders.recordshopapi.models;

public enum Genre {
    POP,
    ROCK,
    JAZZ,
    SOUL,
    CLASSICAL
}
